﻿Public Class frm_Login
    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        End
    End Sub

    Private Sub btn_Login_Click(sender As Object, e As EventArgs) Handles btn_Login.Click

        Dim s_username, s_password As String

        s_username = txt_username.Text
        s_password = txt_password.Text

        'username = alex and password = 123

        If s_username = "alex" And s_password = "123" Then
            Dim f As New frm_Main
            f.ShowDialog()
            f.Dispose()
            Me.Close()
        Else
            MsgBox("Wrong username and password")
        End If



    End Sub
End Class