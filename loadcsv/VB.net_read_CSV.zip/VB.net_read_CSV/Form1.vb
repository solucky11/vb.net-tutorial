﻿Imports System.Data.OleDb
Public Class frm_readcsv

    Dim ds1 As New DataSet
    Private Sub btn_read_Click(sender As Object, e As EventArgs) Handles btn_read.Click
        ds1.Clear()

        Dim _filename As String
        _filename = "H:\Project\Project_Tut\VB.net readCSV\"

        Dim _conn As String

        _conn = "Provider=Microsoft.Jet.OLEDB.4.0;" & "Data Source=" & _filename & ";Extended Properties='text;HDR=YES;FMT=Delimited;'"


        Dim _connection As OleDbConnection = New OleDbConnection(_conn)
        Dim da As OleDbDataAdapter = New OleDbDataAdapter
        Dim _command As OleDbCommand = New OleDbCommand

        _command.Connection = _connection
        _command.CommandText = "SELECT * FROM [Device_Master.csv]"
        da.SelectCommand = _command

        Try
            da.Fill(ds1, "Device_Master")
            Me.DataGridView1.DataSource = ds1
            Me.DataGridView1.DataMember = "Device_Master"
        Catch ex As Exception
            MsgBox("Import Failed, correct column name in the sheet!")
        End Try



    End Sub
End Class
