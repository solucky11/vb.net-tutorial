﻿Imports System.Data.OleDb
Public Class frm_LoadExcel

    Dim ds1 As New DataSet

    Private Sub btn_loadexcel_Click(sender As Object, e As EventArgs) Handles btn_loadexcel.Click

        ds1.Clear()

        Dim _filename As String
        _filename = "H:\Project\Project_Tut\vb.net_load_excel\Device_Master.xlsx"
        Dim _conn As String
        _conn = "Provider=Microsoft.Jet.OLEDB.4.0;" & "Data Source=" & _filename & ";" & "Extended Properties=Excel 8.0;"
        Dim _connection As OleDbConnection = New OleDbConnection(_conn)
        Dim da As OleDbDataAdapter = New OleDbDataAdapter
        Dim _command As OleDbCommand = New OleDbCommand
        Dim _sql As String
        _sql = "SELECT * FROM [Device_Master$] order by id"

        _command.Connection = _connection
        _command.CommandText = _sql
        da.SelectCommand = _command

        Try
            da.Fill(ds1, "Device_Master")
            Me.DataGridView1.DataSource = ds1
            Me.DataGridView1.DataMember = "Device_Master"
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try




    End Sub
End Class
